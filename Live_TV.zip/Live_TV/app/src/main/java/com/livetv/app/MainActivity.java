package com.livetv.app;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private RequestQueue requestQueue;
    private boolean isPlayerOpen = false;
    private String currentMode = "mobile";
    private static final String TAG = "LiveTV_UserApp";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setupStatusBar();
        setupWebView();

        requestQueue = Volley.newRequestQueue(this);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            checkForUpdate();
        }, 2000);
    }

    private void setupStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#0a0a0a"));
            window.setNavigationBarColor(Color.parseColor("#0a0a0a"));
        }
    }

    private String loadAssetText(String fileName) {
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            return new String(buffer, "UTF-8");
        } catch (IOException e) {
            Log.e(TAG, "Failed to load asset: " + fileName, e);
            return "";
        }
    }

    private void setupWebView() {
        webView = findViewById(R.id.webview);
        if (webView == null) {
            Log.e(TAG, "WebView is null! Check activity_main.xml");
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            webSettings.setAllowFileAccessFromFileURLs(true);
            webSettings.setAllowUniversalAccessFromFileURLs(true);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "WebView error: " + description);
                String html = loadAssetText("index.html");
                view.loadDataWithBaseURL("https://app.local/", html, "text/html", "UTF-8", null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectTVModeDetection();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(resource)) {
                            request.grant(new String[]{PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID});
                            return;
                        }
                    }
                    request.grant(request.getResources());
                }
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                super.onShowCustomView(view, callback);
            }

            @Override
            public void onHideCustomView() {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                super.onHideCustomView();
            }
        });

        webView.addJavascriptInterface(new WebAppInterface(), "Android");
        webView.addJavascriptInterface(new TVInterface(), "TVController");

        String htmlContent = loadAssetText("index.html");
        webView.loadDataWithBaseURL("https://app.local/", htmlContent, "text/html", "UTF-8", null);
    }

    private void injectTVModeDetection() {
        String js = "javascript:(function(){"
                + "var isTV = navigator.userAgent.indexOf('Android TV') > -1 || "
                + "navigator.userAgent.indexOf('TV') > -1 || window.TVController !== undefined;"
                + "if (isTV && window.setTVMode) window.setTVMode(true);"
                + "})();";
        webView.loadUrl(js);
    }

    // ---------- JavaScript Interface ----------
    private class WebAppInterface {
        @JavascriptInterface
        public void setPlayerOpen(boolean open) {
            isPlayerOpen = open;
            Log.d(TAG, "Player open: " + open);
        }

        @JavascriptInterface
        public void closePlayer() {
            runOnUiThread(() -> {
                if (webView != null) webView.loadUrl("javascript:closePlayerFromApp();");
            });
        }

        @JavascriptInterface
        public void setOrientation(String mode) {
            currentMode = mode;
            runOnUiThread(() -> {
                try {
                    if ("tv".equals(mode))
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                    else
                        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                } catch (Exception e) {
                    Log.e(TAG, "Orientation error: " + e.getMessage());
                }
            });
        }

        @JavascriptInterface
        public void forceLandscape() {
            runOnUiThread(() -> setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));
        }

        @JavascriptInterface
        public void onPlayerClosed() {
            runOnUiThread(() -> {
                if ("mobile".equals(currentMode))
                    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            });
        }

        @JavascriptInterface
        public void showExitDialog() {
            runOnUiThread(() -> showExitDialog());
        }

        @JavascriptInterface
        public boolean isTV() {
            return getPackageManager().hasSystemFeature(PackageManager.FEATURE_LEANBACK);
        }
    }

    private class TVInterface {
        @JavascriptInterface
        public void onKeyDown(int keyCode) {
            runOnUiThread(() -> webView.loadUrl("javascript:if(window.handleTVKey) handleTVKey(" + keyCode + ", true);"));
        }

        @JavascriptInterface
        public void onKeyUp(int keyCode) {
            runOnUiThread(() -> webView.loadUrl("javascript:if(window.handleTVKey) handleTVKey(" + keyCode + ", false);"));
        }

        @JavascriptInterface
        public void moveFocus(int direction) {
            runOnUiThread(() -> webView.loadUrl("javascript:if(window.moveTVFocus) moveTVFocus(" + direction + ");"));
        }

        @JavascriptInterface
        public void selectCurrent() {
            runOnUiThread(() -> webView.loadUrl("javascript:if(window.selectTVItem) selectTVItem();"));
        }

        @JavascriptInterface
        public void goBack() {
            runOnUiThread(() -> webView.loadUrl("javascript:if(window.goBackTV) goBackTV();"));
        }
    }

    // ---------- Key Handling ----------
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
                webView.loadUrl("javascript:if(window.moveTVFocus) moveTVFocus(0);");
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                webView.loadUrl("javascript:if(window.moveTVFocus) moveTVFocus(1);");
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                webView.loadUrl("javascript:if(window.moveTVFocus) moveTVFocus(2);");
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                webView.loadUrl("javascript:if(window.moveTVFocus) moveTVFocus(3);");
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                webView.loadUrl("javascript:if(window.selectTVItem) selectTVItem();");
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (isPlayerOpen) {
                    webView.loadUrl("javascript:closePlayerFromApp();");
                    return true;
                }
                // প্লেয়ার বন্ধ থাকলে এক্সিট ডায়ালগ দেখাও
                showExitDialog();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                webView.loadUrl("javascript:if(window.togglePlayPause) togglePlayPause();");
                return true;
        }
        webView.loadUrl("javascript:if(window.handleTVKey) handleTVKey(" + keyCode + ", true);");
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        webView.loadUrl("javascript:if(window.handleTVKey) handleTVKey(" + keyCode + ", false);");
        return super.onKeyUp(keyCode, event);
    }

    // ---------- Update Check ----------
    private int getCurrentVersionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 1;
        }
    }

    private String getCurrentVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "1.0.0";
        }
    }

    private void checkForUpdate() {
        String url = "https://tv-app-c8a76-default-rtdb.firebaseio.com/updates/latest.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    int latestVersionCode = response.optInt("versionCode", 1);
                    String latestVersionName = response.optString("versionName", "1.0.0");
                    String releaseNotes = response.optString("releaseNotes", "");
                    String downloadUrl = response.optString("downloadUrl", response.optString("apkUrl", ""));
                    boolean forceUpdate = response.optBoolean("forceUpdate", false);

                    if (latestVersionCode > getCurrentVersionCode() && !downloadUrl.isEmpty()) {
                        runOnUiThread(() -> showUpdateDialog(latestVersionName, releaseNotes, downloadUrl, forceUpdate));
                    }
                },
                error -> Log.e(TAG, "Update check failed")
        );
        requestQueue.add(request);
    }

    private void showUpdateDialog(String newVersionName, String releaseNotes, String downloadUrl, boolean forceUpdate) {
        try {
            // প্রথমে কাস্টম লেআউট চেষ্টা করি
            LayoutInflater inflater = getLayoutInflater();
            View dialogView = inflater.inflate(R.layout.dialog_premium_update, null);
            
            TextView tvCurrent = dialogView.findViewById(R.id.tv_current_version);
            TextView tvNew = dialogView.findViewById(R.id.tv_new_version);
            TextView tvNotes = dialogView.findViewById(R.id.tv_release_notes);
            MaterialButton btnUpdate = dialogView.findViewById(R.id.btn_update);
            MaterialButton btnLater = dialogView.findViewById(R.id.btn_later);
            View badge = dialogView.findViewById(R.id.update_badge);
            TextView tvBadge = dialogView.findViewById(R.id.tv_update_badge);

            tvCurrent.setText("বর্তমান সংস্করণ: v" + getCurrentVersionName());
            tvNew.setText("v" + newVersionName);
            tvNotes.setText(releaseNotes);
            if (forceUpdate) {
                badge.setVisibility(View.VISIBLE);
                tvBadge.setText("গুরুত্বপূর্ণ");
            } else {
                badge.setVisibility(View.GONE);
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.PremiumDialogTheme);
            builder.setView(dialogView);
            AlertDialog dialog = builder.create();
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }

            btnUpdate.setOnClickListener(v -> {
                dialog.dismiss();
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)));
                    Toast.makeText(this, "ব্রাউজার থেকে APK ডাউনলোড করে ইনস্টল করুন", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "লিংক ওপেন করতে ব্যর্থ", Toast.LENGTH_SHORT).show();
                }
            });

            btnLater.setOnClickListener(v -> {
                dialog.dismiss();
                if (forceUpdate) finishAffinity();
            });

            if (forceUpdate) btnLater.setVisibility(View.GONE);
            dialog.setCancelable(!forceUpdate);
            dialog.show();
        } catch (Exception e) {
            // কাস্টম লেআউট ব্যর্থ হলে সাধারণ AlertDialog দেখাই
            Log.e(TAG, "Custom update dialog failed, using simple dialog", e);
            showSimpleUpdateDialog(newVersionName, releaseNotes, downloadUrl, forceUpdate);
        }
    }

    private void showSimpleUpdateDialog(String newVersionName, String releaseNotes, String downloadUrl, boolean forceUpdate) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔄 নতুন আপডেট: v" + newVersionName);
        String message = "বর্তমান সংস্করণ: v" + getCurrentVersionName() + "\n\n" + releaseNotes;
        builder.setMessage(message);
        builder.setPositiveButton("আপডেট", (dialog, which) -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)));
                Toast.makeText(this, "ব্রাউজার থেকে APK ডাউনলোড করে ইনস্টল করুন", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(this, "লিংক ওপেন করতে ব্যর্থ", Toast.LENGTH_SHORT).show();
            }
        });
        if (!forceUpdate) {
            builder.setNegativeButton("পরে", (dialog, which) -> dialog.dismiss());
        }
        builder.setCancelable(!forceUpdate);
        builder.show();
    }

    // ---------- Exit Dialog ----------
    private void showExitDialog() {
        try {
            LayoutInflater inflater = getLayoutInflater();
            View view = inflater.inflate(R.layout.dialog_exit, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.PremiumDialogTheme);
            builder.setView(view);
            AlertDialog dialog = builder.create();
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
            MaterialButton btnYes = view.findViewById(R.id.btn_yes);
            MaterialButton btnNo = view.findViewById(R.id.btn_no);
            btnYes.setOnClickListener(v -> { dialog.dismiss(); finish(); });
            btnNo.setOnClickListener(v -> dialog.dismiss());
            dialog.show();
        } catch (Exception e) {
            // ফলব্যাক ডায়ালগ
            new AlertDialog.Builder(this)
                    .setTitle("বন্ধ করুন")
                    .setMessage("আপনি কি অ্যাপটি বন্ধ করতে চান?")
                    .setPositiveButton("হ্যাঁ", (d, w) -> finish())
                    .setNegativeButton("না", null)
                    .show();
        }
    }

    @Override
    public void onBackPressed() {
        // WebView-এর ব্যাক হিস্ট্রি আগে চেক করি
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        // প্লেয়ার ওপেন থাকলে বন্ধ করি
        if (isPlayerOpen) {
            webView.loadUrl("javascript:closePlayerFromApp();");
            return;
        }
        // অন্যথায় এক্সিট ডায়ালগ
        showExitDialog();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (requestQueue != null) requestQueue.cancelAll(r -> true);
        if (webView != null) webView.destroy();
    }
}